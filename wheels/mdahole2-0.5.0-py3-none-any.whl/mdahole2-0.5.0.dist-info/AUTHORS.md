# Authors

mdahole2 was created by Ian Kenney in 2022.


All contributing authors are listed in this file below.
The repository history at https://github.com/MDAnalysis/mdahole2
and the CHANGELOG show individual code contributions.

## Chronological list of authors

<!--
The rules for this file:
  * Authors are sorted chronologically, earliest to latest
  * Please format it each entry as "Preferred name <GitHub username>"
  * Your preferred name is whatever you wish to go by --
    it does *not* have to be your legal name!
  * Please start a new section for each new year
  * Don't ever delete anything
-->

**2012**
- Oliver Beckstein <@orbeckst>
- Jinju Lu <jjlights03@gmail.com>
- Tyler Reddy <@tylerjereddy>

**2013**
- Elizabeth Denning <denniej0@gmail.com>

**2014**
- Manuel Nuno Melo <@mnmelo>
- Richard Gowers <@richardjgowers>

**2015**
- Sébastien Buchoux <@seb-buch>
- Gorman Stock <@gormanstock>
- David Dotson <@dotsdl>
- Max Linke <@kain88-de>
- Sean L. Seyler <@sseyler>

**2016**
- Jonathan Barnoud <@jbarnoud>
- Matteo Tiberti <@mtiberti>

**2018**
- Mateusz Bieniek <@bieniekmateusz>

**2019**
- João M.C. Teixeira <@joaomcteixeira>
- Rocco Meli <@RMeli>

**2020**
- Irfan Alibay <@IAlibay>
- Lily Wang <@lilyminium>
- Paul Smith <@p-j-smith>
- Philip Loche <@PicoCentauri>

**2022**
- Atharva Kulkarni <@Atharva7K>
- Manish Kumar <@manishsaini6421>
- Matthijs Tadema <@mjtadema>
- Tengyu Xie <@miss77jun>
- Estefania Barreto-Ojeda <@ojeda-e>
- Ian Kenney <@ianmkenney>
