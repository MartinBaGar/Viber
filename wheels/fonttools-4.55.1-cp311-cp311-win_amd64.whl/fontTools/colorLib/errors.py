class ColorLibError(Exception):
    pass
